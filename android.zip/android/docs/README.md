# Android Build Docs

* [android_app_bundles.md](android_app_bundles.md)
* [build_config.md](build_config.md)
* [coverage.md](coverage.md)
* [lint.md](lint.md)
* [life_of_a_resource.md](life_of_a_resource.md)
* [../incremental_install/README.md](../incremental_install/README.md)

See also:
* [//build/README.md](../../README.md)

                                                                                              API 2022

 Linux find Local State

Close browser! command

cp 'Local State' ~/.config/chromium

and opera , chrome

cp 'Local State' ~/.config/opera

cp 'Local State' ~/.config/google-chrome

cp 'Local State' ~/.config/google-chrome-unstable

 Windows find Local State replace re run browser

Griggorii@gmail.com
